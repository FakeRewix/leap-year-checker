package com.company;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("Vyberte si aplikaci:");
            System.out.println("1. Zjištění přestupného roku podle zadaného roku");
            System.out.println("2. Zjištění přestupného roku podle aktuálního data");
            System.out.println("3. Vlastní formát data a času podle systémového času");
            System.out.println("4. Zbývající čas do určitého data");
            System.out.println("5. Ukončit program");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Zadejte rok pro zjištění, zda je přestupný:");
                    int year = sc.nextInt();
                    boolean isLeapYear = leapYear(year);
                    System.out.println("Rok " + year + " " + (isLeapYear ? "je" : "není") + " přestupný.");
                    System.out.println("");
                    break;

                case 2:
                    int currentYear = Calendar.getInstance().get(Calendar.YEAR);
                    boolean isCurrentYearLeap = leapYear(currentYear);
                    System.out.println("Aktuální rok " + currentYear + " " + (isCurrentYearLeap ? "je" : "není") + " přestupný.");
                    if (!isCurrentYearLeap) {
                        int nextLeapYear = findNextLeapYear(currentYear);
                        System.out.println("Další přestupný rok bude: " + nextLeapYear);
                        System.out.println("");
                    }
                    break;

                case 3:
                    long currentTimeMillis = System.currentTimeMillis();
                    String formattedDateTime = formatSystemTime(currentTimeMillis);
                    System.out.println("Aktuální systémový čas: " + formattedDateTime);
                    System.out.println("");
                    break;

                case 4:
                    System.out.println("Zadejte cílový den:");
                    int day = sc.nextInt();
                    System.out.println("Zadejte cílový měsíc (1-12):");
                    int month = sc.nextInt();
                    System.out.println("Zadejte cílový rok:");
                    int targetYear = sc.nextInt();

                    Calendar targetDate = Calendar.getInstance();
                    targetDate.set(targetYear, month - 1, day);

                    Calendar currentDate = Calendar.getInstance();
                    long remainingMillis = targetDate.getTimeInMillis() - currentDate.getTimeInMillis();

                    long remainingSeconds = remainingMillis / 1000;
                    long remainingMinutes = remainingSeconds / 60;
                    long remainingHours = remainingMinutes / 60;
                    long remainingDays = remainingHours / 24;
                    long remainingMonths = remainingDays / 30;
                    long remainingYears = remainingMonths / 12;

                    System.out.println("Zbývá: " + remainingYears + " let, " + remainingMonths % 12 + " měsíců, " +
                            remainingDays % 30 + " dní, " + remainingHours % 24 + " hodin, " +
                            remainingMinutes % 60 + " minut, " + remainingSeconds % 60 + " sekund.");
                    System.out.println("");
                    break;

                case 5:
                    running = false;
                    System.out.println("Program byl ukončen.");
                    break;

                default:
                    System.out.println("Vybrals špatně.");
            }
        }
    }

    private static boolean leapYear(int year) {
        if (year % 4 != 0) {
            return false;
        } else if (year % 100 != 0) {
            return true;
        } else {
            return year % 400 == 0;
        }
    }

    private static int findNextLeapYear(int currentYear) {
        int nextYear = currentYear + 1;
        while (true) {
            if (leapYear(nextYear)) {
                return nextYear;
            }
            nextYear++;
        }
    }

    private static String formatSystemTime(long currentTimeMillis) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
        return dateFormat.format(currentTimeMillis);
    }
}